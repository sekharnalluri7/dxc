package com.dxc.ass.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.ass.dao.UserFormDAO;
import com.dxc.ass.dao.UserFormDAOImpl;
import com.dxc.ass.model.UserForm;

/**
 * Servlet implementation class ValidateServlet
 */
@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet {
	boolean a;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		
		UserFormDAO userDAO=new UserFormDAOImpl();
		 a=userDAO.validateUser(username, password);
		 if(a==true)
			 response.getWriter().print("Success");
		 else
			 response.getWriter().print("Fail");
		
	}

}
