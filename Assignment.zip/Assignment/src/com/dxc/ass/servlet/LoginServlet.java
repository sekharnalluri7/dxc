package com.dxc.ass.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.ass.dao.UserFormDAO;
import com.dxc.ass.dao.UserFormDAOImpl;
import com.dxc.ass.model.UserForm;

import jdk.nashorn.internal.ir.RuntimeNode.Request;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String fullName=request.getParameter("fullName");
		String gender=request.getParameter("gender");
		String qualification=request.getParameter("qualification");
		response.getWriter().print(qualification);
		UserForm userform=new UserForm(username, password, fullName, gender, qualification);
		UserFormDAO userDAO=new UserFormDAOImpl();
		userDAO.addUser(userform);
		
		
		RequestDispatcher dispatch=request.getRequestDispatcher("loginform.html");
		dispatch.forward(request, response);
		
		
		
	}

}
