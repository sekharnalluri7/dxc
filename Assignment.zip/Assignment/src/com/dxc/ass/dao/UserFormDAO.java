package com.dxc.ass.dao;

import com.dxc.ass.model.UserForm;

public interface UserFormDAO {
	public void addUser(UserForm userForm);
	public boolean validateUser(String username,String password);

}
