package com.dxc.ass.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.ass.dbcon.DBConnection;
import com.dxc.ass.model.UserForm;


public class UserFormDAOImpl implements UserFormDAO{
	private static final String FETCH_USER = "insert into userform values(?,?,?,?,?)";
	private static final String CHECK_USER = "select * from userform where Name=? and Password=?";
	
	private UserForm userForm=new UserForm();
	Connection connection = DBConnection.getConnection();

	@Override
	public void addUser(UserForm userForm) {
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(FETCH_USER);
			preparedStatement.setString(1, userForm.getUsername());
			preparedStatement.setString(2, userForm.getPassword());
			preparedStatement.setString(3, userForm.getQualification());
			preparedStatement.setString(5, userForm.getFullName());
			preparedStatement.setString(4, userForm.getGender());
			
			

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public boolean validateUser(String username, String password) {
		boolean userExists = false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement(CHECK_USER);
			preparedStatement.setString(1,username);
			preparedStatement.setString(2,password);
			
			ResultSet res = preparedStatement.executeQuery();
			if(res.next())
				userExists = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return userExists;
	}

}
