package com.dxc.other;

import java.awt.AWTException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

@Test
public class Third {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1() throws IOException, InterruptedException{
		SoftAssert st=new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		driver.get("https://www.msn.com/en-in/"); //open url
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//click on one note
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		
		Set<String> allids = driver.getWindowHandles();
		Iterator<String> it=allids.iterator();
		String mid=it.next();
		String t1=it.next();
		driver.switchTo().window(t1);
		//enter phone number
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("9899898989");
		
		
		Thread.sleep(3000);
		//close tab window
		driver.close();
		//switch to main window reference
		driver.switchTo().window(mid);
		Thread.sleep(3000);
		//click on skype
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		
		Thread.sleep(3000);
	
		
		
	}

}
