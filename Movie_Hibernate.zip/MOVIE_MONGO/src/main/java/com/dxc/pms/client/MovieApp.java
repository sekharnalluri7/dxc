package com.dxc.pms.client;

import java.util.Scanner;

import com.dxc.pms.dao.MovieDAO;
import com.dxc.pms.dao.MovieDAOImpl;
import com.dxc.pms.model.Movie;

public class MovieApp {
	MovieDAO movieDAO;
	int choice = 0;
	int movieID;
	String movieName;
	int budget;
	String dirName;
	Scanner scanner = new Scanner(System.in);

	public MovieApp() {

		this.movieDAO = new MovieDAOImpl();

	}

	public void launchMovieApp() {

		while (true) {
			System.out.println("M E N U ");
			System.out.println("1. Add The Movie Names : ");
			System.out.println("2. Get All The Movie Details : ");
			System.out.println("3. Get Movie by id : ");
			System.out.println("4. Delete Movie by id : ");
			System.out.println("5. Update Movie details by id : ");
			System.out.println("6. E X I T");

			System.out.println("Please enter your choice : (1-6)");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				Movie movie = takeMovieInput();
				if (!movieDAO.isPMovieExists(movie.getMovieID())) {
					movieDAO.addMovie(movie);
				} else {
					System.out.println("Movie already exists with id : " + movieID);
				}
				break;
			case 2:
				System.out.println(movieDAO.getAllMovies());
				break;
			case 3:
				System.out.println("Please enter Movie id to search :");
				movieID = scanner.nextInt();
				if (movieDAO.isPMovieExists(movieID)) {
					Movie searchedMovie = movieDAO.getMovie(movieID);
					System.out.println(searchedMovie);
				} else {
					System.out.println("Movie Id not found");
				}
				break;
			case 4:
				System.out.println("Please enter Movie id to delete :");
				movieID = scanner.nextInt();
				if (movieDAO.isPMovieExists(movieID)) {
					movieDAO.deleteMovie(movieID);
					System.out.println("Movie deleted successfully");
				} else {
					System.out.println("Movie Id not found");
				}
				break;
			case 5:
				System.out.println("Welcome to Movie app category : ");
				Movie movieToUpdate = takeMovieInput();
				if (movieDAO.isPMovieExists(movieToUpdate.getMovieID())) {
					movieDAO.updateMovie(movieToUpdate);
					System.out.println("Your movie updated successfully ");
				} else {
					System.out.println("movie id does not exists");
				}
				break;
			case 6:
				System.out.println("Thanks for using my app");
				System.exit(0);
			default:
				System.out.println(" Please enter (1-3)");
			}
		}
	}

	private Movie takeMovieInput() {
		System.out.println("Please enter Movie id :");
		movieID = scanner.nextInt();
		System.out.println("Please enter movie name :");
		movieName = scanner.next();
		System.out.println("Please enter the budget :");
		budget = scanner.nextInt();
		System.out.println("Please enter name of director :");
		dirName = scanner.next();

		Movie movie = new Movie(movieID, movieName, budget, dirName);
		return movie;
	}
}
