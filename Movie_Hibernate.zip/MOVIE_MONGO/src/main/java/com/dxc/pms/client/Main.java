package com.dxc.pms.client;

public class Main {

	public Main() {
	}

	public static void main(String[] args) {
		System.out.println("###########  MOVIE  APP########");
		MovieApp app = new MovieApp();
		app.launchMovieApp();
	}
}