/* import React, { Component } from 'react';

class App extends Component {
    render() {
        return (
            <div className="myDiv">
                <a href="home">Home</a>
                <a href="customer">Customers</a>
                <a href="employee">Employees</a>
                <a href="product">Products</a>
                <hr/>
                <h1>Home page - Welcome to DXC</h1>
                
            </div>
        );
    }
}

export default App; */
import React, { Component } from 'react'

import axios from 'axios'
class App extends Component {
    constructor() {
        super()
        this.state = {
            username: ''
        }
        this.handleClick = this.handleClick.bind(this)
    }
    handleClick() {
        console.log("handleClick Called")
        axios.get('https://api.github.com/users/smohit02')
            .then(response => this.setState({ username: response.data.id }))
    }
    render() {
        return (
            <div className='btn'>
                <input type="text" name="username"></input>
                <button className='button' onClick={this.handleClick}>Click Me</button>
                <p>{this.state.username}</p>
            </div>
        )
    }
}
export default App
