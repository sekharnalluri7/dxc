package com.dxc.pms.dao;



import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dxc.pms.model.Doctor;
import com.dxc.pms.model.HospitalDetails;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	DoctorDAOImpl impl;
	
	protected void setUp() throws Exception {
		impl=new DoctorDAOImpl();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	public void testGetDoctor() {
		HospitalDetails hd=new HospitalDetails("RMK","Bengaluru");
		Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
		hds.add(hd);
		Doctor doctor=new Doctor(89,"Saqlain",350,hds);
		impl.addDoctor(doctor);
		Doctor newDoc=impl.getDoctor(89);
		assertNotNull(newDoc);
		impl.deleteDoctor(89);
	}

	public void testGetAllDoctor() {
		List<Doctor> list1=impl.getAllDoctor();
		HospitalDetails hd=new HospitalDetails("RMK","Bengaluru");
		Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
		hds.add(hd);
		Doctor doctor=new Doctor(47,"Saqlain",450,hds);
		impl.addDoctor(doctor);
		List<Doctor> list2=impl.getAllDoctor();
		assertNotSame(list1, list2);
		impl.deleteDoctor(47);
	}

	public void testAddDoctor() {
		List<Doctor> list1=impl.getAllDoctor();
		HospitalDetails hd=new HospitalDetails("RMK","Bengaluru");
		Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
		hds.add(hd);
		Doctor doctor=new Doctor(29,"Siddhu",450,hds);
		impl.addDoctor(doctor);
		List<Doctor> list2=impl.getAllDoctor();
		assertNotSame(list1.size(), list2.size());
		impl.deleteDoctor(29);
	}

	public void testDeleteDoctor() {
		
		HospitalDetails hd=new HospitalDetails("RMK","Bengaluru");
		Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
		hds.add(hd);
		Doctor doctor=new Doctor(30,"Siddhu",450,hds);
		impl.addDoctor(doctor);
		List<Doctor> list1=impl.getAllDoctor();
		impl.deleteDoctor(30);
		List<Doctor> list2=impl.getAllDoctor();
		assertNotSame(list1.size(), list2.size());
	}

	public void testUpdateDoctor() {
		HospitalDetails hd=new HospitalDetails("JISHNU","Bengaluru");
		Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
		hds.add(hd);
		Doctor doctor=new Doctor(89,"Sumanth",550,hds);
		impl.addDoctor(doctor);
		System.out.println(doctor);
		Doctor doctor1=new Doctor(89,"Dwarak",300,hds);
		System.out.println(doctor1);
		impl.updateDoctor(doctor);
		System.out.println(doctor);
		assertNotSame(doctor, doctor1);
		impl.deleteDoctor(89);

	}

	public void testIsDoctorExists() {
		HospitalDetails hd=new HospitalDetails("JISHNU","Bengaluru");
		Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
		hds.add(hd);
		Doctor doctor=new Doctor(40,"Prem",550,hds);
		impl.addDoctor(doctor);
		assertEquals(true,impl.isDoctorExists(40));
		impl.deleteDoctor(40);		
		
	}

	public void testGetAllDoctorNames() {
		HospitalDetails hd=new HospitalDetails("Ramakrishna","Bengaluru");
		Set<HospitalDetails> hds=new HashSet<HospitalDetails>();
		hds.add(hd);
		Doctor doctor=new Doctor(79,"Prem",550,hds);
		impl.addDoctor(doctor);
		List<String> name=impl.getAllDoctorNames();
			
		assertNotSame("Prem",name);
		impl.deleteDoctor(79);		
		
	}

	public void testGetAllDoctors() {
		List<Doctor> docs=impl.getAllDoctors("Saqlain");
		System.out.println(docs);
		 assertEquals(docs.size(), 2);
	}

}
