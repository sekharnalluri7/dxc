package com.dxc.pms.dao;
import static org.junit.Assert.assertEquals; 
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.model.Product;


public class ProductServiceControllerTest extends AbstractTest {
   @Override
   @Before
   public void setUp() {
      super.setUp();
   }
   @Test
   public void getProductsList() throws Exception {
      
	   //localhost:8001/product		-GET ALL			GET
	   String uri = "/product";
      
      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
         .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
      
      int status = mvcResult.getResponse().getStatus();
      
      assertEquals(200, status);
      
      String content = mvcResult.getResponse().getContentAsString();
      Product[] productlist = super.mapFromJson(content, Product[].class);
      assertTrue(productlist.length > 0 );
   }
   
   
   @Test
   public void getProducts() throws Exception {
      
	   String uri = "/product/1001";
      
      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
         .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
      
      int status = mvcResult.getResponse().getStatus();
      
      assertEquals(200, status);
      
      String content = mvcResult.getResponse().getContentAsString();
      Product productlist = super.mapFromJson(content, Product.class);
      assertNotNull(productlist);
   }
 
}