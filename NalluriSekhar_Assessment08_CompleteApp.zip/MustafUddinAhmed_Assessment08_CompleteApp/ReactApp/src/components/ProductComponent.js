import React, { Component } from "react";
import ProductDataService from "../services/ProductDataService";
import { Formik, Form, Field, ErrorMessage } from "formik";

class ProductComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      status: "true",
      productId: this.props.match.params.productId,
      productName: "",
      quantityOnHand: "",
      price: "",
      button: "Update",
      message: ""
    };
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentWillMount() {
    if (this.state.productId == -1) {
      this.setState({
        status: false,
        productId: "",
        button: "Add"
      });
      return;
    }
    ProductDataService.getProduct(this.state.productId).then(response => {
      this.setState({
        productName: response.data.productName,
        quantityOnHand: response.data.quantityOnHand,
        price: response.data.price
      });
    });
  }

  onSubmit(product) {
    if (this.state.productId == "") {
      console.log("Add Clicked");

      ProductDataService.addProduct(product)
        .then(response => {
          console.log(response.status);
          this.props.history.push("/");
        })
        .catch(error => {
          console.log(error);
          this.setState({
            message:
              "Product with Product Id" + product.productId + " already exists"
          });
        });
    } else {
      console.log(product);
      ProductDataService.updateProduct(product).then(() =>
        this.props.history.push("/")
      );
    }
  }

  validateProductForm(product) {
    let error = {};
    if (!product.productName) {
      error.productName = "Enter a Product Name";
    } else if (!product.quantityOnHand) {
      error.quantityOnHand = "Enter Quantity On Hand";
    } else if (!product.price) {
      error.price = "Enter price";
    } else if (product.price < 0) {
      error.price = "Price cannot be negative";
    } else if (product.quantityOnHand < 0) {
      error.quantityOnHand = "Quantity cannot be negative";
    }
    return error;
  }

  render() {
    let { productId, productName, quantityOnHand, price, button } = this.state;
    return (
      <div>
        {" "}
        <center>
          {button} Product <br />
        </center>
        <h2 className="alert alert" align="center">
          {this.state.message}
        </h2>
        {/* Update Product Id:{productId}
        <br />
        Product Name : {productName}
        <br />
        Quantity : {quantityOnHand}
        <br />
        Price : {price}
        <br /> */}
        <div className="container">
          <Formik
            initialValues={{ productId, productName, quantityOnHand, price }}
            enableReinitialize={true}
            onSubmit={this.onSubmit}
            validateOnChange={false}
            validateOnBlur={false}
            validate={this.validateProductForm}
          >
            <Form>
              <fieldset className="form-group">
                <label>Product Id</label>
                <Field
                  className="form-control"
                  type="text"
                  name="productId"
                  disabled={this.state.status}
                ></Field>
              </fieldset>
              <fieldset className="form-group">
                <label>Product Name</label>
                <Field
                  className="form-control"
                  type="text"
                  name="productName"
                ></Field>
              </fieldset>
              <ErrorMessage
                name="productName"
                component="div"
                className="alert alert-danger"
              ></ErrorMessage>
              <fieldset className="form-group">
                <label>Quantity On Hand</label>
                <Field
                  className="form-control"
                  type="text"
                  name="quantityOnHand"
                ></Field>
              </fieldset>
              <ErrorMessage
                name="quantityOnHand"
                component="div"
                className="alert alert-danger"
              ></ErrorMessage>
              <fieldset className="form-group">
                <label>Price</label>
                <Field
                  className="form-control"
                  type="text"
                  name="price"
                ></Field>
              </fieldset>
              <ErrorMessage
                name="price"
                component="div"
                className="alert alert-danger"
              ></ErrorMessage>
              <button className="btn btn-success" type="submit">
                {this.state.button}
              </button>
            </Form>
          </Formik>
        </div>
      </div>
    );
  }
}

export default ProductComponent;
