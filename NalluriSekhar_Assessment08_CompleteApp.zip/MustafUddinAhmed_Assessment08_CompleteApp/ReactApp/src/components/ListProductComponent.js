import React, { Component } from "react";
import ProductDataService from "../services/ProductDataService";

class ListProductComponent extends Component {
  constructor(props) {
    super(props);
    this.refreshProduct = this.refreshProduct.bind(this);
    this.deleteProductClicked = this.deleteProductClicked.bind(this);
    this.updateProductClicked = this.updateProductClicked.bind(this);
    // this.addProductClicked = this.addProductClicked.bind(this);
    this.state = {
      products: [],
      message: ""
    };
  }

  componentWillMount() {
    this.refreshProduct();
  }

  refreshProduct() {
    ProductDataService.getAllProducts().then(response => {
      this.setState({
        products: response.data
      });
    });
  }

  deleteProductClicked(productIdtoDelete) {
    ProductDataService.deleteProduct(productIdtoDelete).then(response => {
      this.setState({
        message: "productId " + productIdtoDelete + " deleted successfully"
      });
      this.refreshProduct();
    });
  }

  updateProductClicked(productId) {
    this.props.history.push(`/products/${productId}`);
  }

  addProductClicked(productId) {
    this.props.history.push(`/products/${productId}`);
  }

  searchButtonClicked() {
    this.props.history.push(`/productSearchByName/`);
  }

  render() {
    return (
      <div>
        {this.state.message && (
          <div className="alert alert-success">{this.state.message}</div>
        )}
        <div className="container" align="center">
          <h3>All Products</h3>
          <div className="container">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th>Product Id</th>
                  <th>Product Name</th>
                  <th>Quantity On Hand</th>
                  <th>Price</th>
                  {/* <th>Add</th> */}
                  <th>Update</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {this.state.products.map(product => (
                  <tr key={product.productId}>
                    <td>{product.productId}</td>
                    <td>{product.productName}</td>
                    <td>{product.quantityOnHand}</td>
                    <td>{product.price}</td>

                    <td>
                      <button
                        className="btn btn-outline-success"
                        onClick={() =>
                          this.updateProductClicked(product.productId)
                        }
                      >
                        Update
                      </button>
                    </td>
                    <td>
                      <button
                        className="btn btn-outline-danger"
                        onClick={() =>
                          this.deleteProductClicked(product.productId)
                        }
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button
              className="btn btn btn-outline-primary"
              onClick={() => this.addProductClicked(-1)}
            >
              Add Product
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => this.searchButtonClicked()}
            >
              Search Product By Name
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default ListProductComponent;
