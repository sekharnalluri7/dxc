package com.dxc.pms.dao;

import com.dxc.pms.model.*;
import java.util.*;

public interface PassengerDAO
{
	
	
	public Ticket getTicket(int pnr);
	public List<Ticket> getAllTickets();
	public void addTicket(Ticket ticket);
	public void cancelTicket(int pnr);
	public void updateTicket(Ticket ticket);
	
}