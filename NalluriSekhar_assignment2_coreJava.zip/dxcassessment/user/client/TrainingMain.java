package com.dxcassessment.user.client;

public class TrainingMain {
	
	  public static void main(String[] args) {
		  TrainingApp app=new TrainingApp();
		  app.launchapp();
	       
		
	}
	       

}
