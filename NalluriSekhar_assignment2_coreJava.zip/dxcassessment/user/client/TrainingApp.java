package com.dxcassessment.user.client;

import java.util.Scanner;

import com.dxcassessment.user.dao.TrainingDAO;
import com.dxcassessment.user.dao.TrainingDAOImpl;
import com.dxcassessment.user.model.Training;

public class TrainingApp {

	Scanner scanner=new Scanner(System.in);
	Training training;
	TrainingDAO trainingDAO = new TrainingDAOImpl();
	int sapId;
	String employeeName;
	String stream;
	int percentage;
	
	
	int choice=0;

	public TrainingApp() {
		// TODO Auto-generated constructor stub
		this.trainingDAO=new TrainingDAOImpl();
	}
	public void launchapp()
	{
		while(true)
		{
			System.out.println("Select one");
			System.out.println("1.Display all records");
			System.out.println("2.Display one by one");
			System.out.println("3.Exit");
			System.out.println("Enter the choice");
			choice=scanner.nextInt();
			switch(choice) {
			case 1:
				System.out.println(trainingDAO.getAllRecords());
				break;
				
			case 2:
				trainingDAO.updatePercentage();
				break;
				
			case 3:
				System.exit(0);
				break;
			}
		}
	}
	
	
	
}
