package com.dxcassessment.user.client;

import java.util.Scanner;

public class Main {

String a;

public static void main(String[] args) {

App app= new App();
boolean status=app.authenticateUserApp();

if(status) {
App trainingApp= new App();
trainingApp.launchApp();
}
else {
System.out.println("UserId and Password Combination is not correct");
}


}

}