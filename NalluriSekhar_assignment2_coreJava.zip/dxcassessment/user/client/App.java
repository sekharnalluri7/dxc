package com.dxcassessment.user.client;

import java.util.Scanner;

import com.dxcassessment.user.dao.UserDAO;
import com.dxcassessment.user.dao.UserDAOImpl;
import com.dxcassessment.user.model.User;

public class App {

	
		Scanner scanner=new Scanner(System.in);
		User user;
		UserDAO userDAO = new UserDAOImpl();
		String userName;
		String password;
		
		
		int choice=0;

		public App() {
			// TODO Auto-generated constructor stub
			this.userDAO=new UserDAOImpl();
		}
		public void validate() {
			System.out.println("Enter Username and password");
			userName=scanner.next();
			password=scanner.next();
			
			User user1=new User(userName, password);
			if(userDAO.validate(user1))
			{
				System.out.println("login successful");
				
			}
			else 
				System.out.println("incorrect details");
		}
			
		}
