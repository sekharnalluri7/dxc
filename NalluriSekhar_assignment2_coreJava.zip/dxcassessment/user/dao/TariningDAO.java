package com.dxcassessment.user.dao;

import java.util.List;

import com.dxcassessment.user.model.Training;

public interface TrainingDAO {

	
	public List<Training>getAllRecords();
public void updatePercentage();

}
