package com.dxcassessment.user.dao;

import com.dxcassessment.user.model.User;

public interface UserDAO {
	boolean validate = false;

	public   boolean validate(User user);
	

}
