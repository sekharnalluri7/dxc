package com.dxcassessment.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxcassessment.user.dbcon.DBConnection;
import com.dxcassessment.user.model.User;



public class UserDAOImpl implements UserDAO{
	Connection connection=DBConnection.getConnection();
	private static final String Fetch_User="Select * from user where username=? and password =?";
	public boolean validate(User user) {
		// TODO Auto-generated method stub
		boolean validate=false;
		PreparedStatement preparedStatement;
		try {
			preparedStatement=connection.prepareStatement(Fetch_User);
			preparedStatement.setString(1,user.getUserName());
			preparedStatement.setString(2,user.getPassword());
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				validate=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return validate;
	}

}