package com.dxc.ont.dao;

import com.dxc.ont.test.Test;


public interface TestDAO{
		 public Test getqatable(int no);

	}


