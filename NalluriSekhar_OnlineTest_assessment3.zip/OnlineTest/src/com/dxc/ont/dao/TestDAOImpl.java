package com.dxc.ont.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.ont.dao.TestDAO;
import com.dxc.ont.dbcon.DBConnection;
import com.dxc.ont.test.Test;

public class TestDAOImpl implements TestDAO {

	public TestDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	Connection connection= DBConnection.getConnection();
	Test test=new Test();
	
	public Test getqatable(int no) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement prepareStatement = connection.prepareStatement("select * from qatable where no = ?");
			prepareStatement.setInt(1, no);
			ResultSet res=prepareStatement.executeQuery();
			res.next();
			
			test.setNo(res.getInt(1));
			test.setQuestion(res.getString(2));
			test.setAnswer(res.getString(3));

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return test;
	}


}
