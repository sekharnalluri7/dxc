package com.dxc.ont.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.RandomlyPicking;
import com.dxc.ont.dao.TestDAO;
import com.dxc.ont.dao.TestDAOImpl;
import com.dxc.ont.test.Test;

/**
 * Servlet implementation class TestServlet
 */
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    TestDAO testDAO=new TestDAOImpl();
	RandomlyPicking randomPicking=new RandomlyPicking();
	int p[] = randomPicking.randomNumbers();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//for(int i=0;i<=2;i++)
		//{
		
		Test test=testDAO.getqatable(p[0]);
		HttpSession session=request.getSession();
		session.setAttribute("no", test);
	//}
		RequestDispatcher dispatcher=request.getRequestDispatcher("Display2.jsp");
		dispatcher.forward(request, response);

		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Test test1=testDAO.getqatable(p[1]);
		HttpSession session=request.getSession();
		session.setAttribute("no1", test1);
		RequestDispatcher dispatcher=request.getRequestDispatcher("Display3.jsp");
		dispatcher.forward(request, response);

	}

}
