package com;

import java.util.Random;
import java.util.stream.IntStream;

public class RandomlyPicking {
	
	public static int[] randomNumbers() {
		Random random =new Random();
		IntStream ints=random.ints(3,1,10);
		//ints.forEach(System.out::println);
		int[] a = new int[3];
		a = ints.toArray();
		return a;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            //Random random =new Random();
            //System.out.println(random.nextDouble()*10);
            //IntStream ints=random.ints(3,1,10);
          //ints.forEach(System.out::println);
		RandomlyPicking ran=new RandomlyPicking();
		int p[] = randomNumbers();
		System.out.println(p[0]);
		System.out.println(p[1]);
		System.out.println(p[2]);
		
	}

}
